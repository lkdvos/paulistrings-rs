// Worked example — the Organic system driving a Typst deck.
// typst compile deck.typ deck.pdf --font-path ./fonts

#import "organic.typ": *

#set text(font: font-body, size: t-body, fill: ink, lang: "en")
#set par(leading: lead-body, justify: false)
#folio-note.update("Confidential — July 2026")

#cover-slide(
  "Organic",
  subtitle: "Warm, rounded and a little playful: a cream-and-sand ground with a terracotta accent and a sage second voice.",
  meta: ("Your name", "July 2026"),
)

#contents-slide(rows: ("Principles", "The ramps", "Imagery", "Roadmap"))

#divider-slide("01", "Principles")

#content-slide("Working rules")[
  #bullets((
    [Round everything that can be round — pills, circles, soft shapes.],
    [Caprasimo speaks display; Figtree carries the reading.],
    [Terracotta leads and the sage is a genuine second voice, not a highlight.],
  ))
]

#columns-slide("Two columns", (
  (
    "Let the text breathe",
    [Two easy columns with a generous gutter — ragged right, because this system never squares text into slabs. Each column keeps its own flush-left axis, and the whitespace between them is the divider.],
  ),
  (
    "Partners, not mirrors",
    [The columns share their top gridline and baseline rhythm, but their endings fall where the copy falls — soft, uneven edges are part of the voice.],
  ),
))

#quadrant-slide(
  "Quadrants",
  (
    ("Let it grow", [Low care, high reward — plant it, water it occasionally, come back in spring.]),
    ("Nurture now", [High care, high reward — the work the terracotta was made to flag.]),
    ("Compost", [Low care, low reward — let it feed something better.]),
    ("Tend lightly", [High care, low reward — prune these back before they take the bed.]),
  ),
  axis: ([← less care], [more care →]),
)

#divider-slide("02", "The ramps")

#table-slide(
  "Color roles",
  header: ("", "Role", "Value", "On the ground", "Use"),
  rows: (
    (swatch(ink), [Text], [\##201e1d], [13.9:1], [Body copy and headings]),
    (swatch(accent), [Terracotta], [\##c67139], [3.0:1], [The lead accent, warm and up front]),
    (swatch(accent2), [Sage], [\##7a8a5e], [3.1:1], [The second voice — a real one]),
    (swatch(accent-700), [Terracotta 700], [\##8c491a], [5.7:1], [Accent-colored body copy]),
  ),
)

#hero-slide(
  "13.9:1",
  [Body text against the warm parchment ground — softer than a white page, still carrying full reading contrast.],
)

#divider-slide("03", "Imagery")

// Pre-wash the file itself; Typst cannot filter an image.
#split-slide(
  "The washed treatment",
  note: [Every photograph is washed — desaturated, lower-contrast and lifted — and an on-page figure crops in a soft organic shape, never a hard box.],
  image("assets/photo.jpg", width: 100%, height: 100%, fit: "cover"),
)

#half-bleed-slide(
  "Half bleed",
  bullets((
    [The photograph bleeds to three edges and holds half the stage],
    [The copy keeps the content rhythm — same gridlines as every slide],
    [Dots still hang left of the text, whatever sits behind them],
  )),
  image("assets/photo.jpg", width: 100%, height: 100%, fit: "cover"),
)

#quote-slide(
  ["Use soft shapes — circles and blobs — as decoration and imagery masks."],
  attribution: [the Organic readme],
)

#cover-slide(
  "Thank you",
  subtitle: "Copy this folder for your next deck — the tokens and layouts carry the look.",
  meta: ("you\@example.com",),
)
